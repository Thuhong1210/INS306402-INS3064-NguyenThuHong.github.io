<?php
require_once 'Database.php';

$db = Database::getInstance()->getConnection();

// 1. Prepare and execute the SQL query
$sql = "SELECT 
            u.name,
            u.email,
            SUM(oi.quantity * oi.unit_price) AS total_spent
        FROM users u
        JOIN orders o ON u.id = o.user_id
        JOIN order_items oi ON o.id = oi.order_id
        GROUP BY u.id, u.name, u.email
        ORDER BY total_spent DESC
        LIMIT 3";

$stmt = $db->prepare($sql);
$stmt->execute();

// 2. Fetch the results
$topCustomers = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top 3 Customers</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 40px 20px;
            min-height: 100vh;
            margin: 0;
        }

        .container {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            padding: 32px;
            width: 100%;
            max-width: 700px;
        }

        h2 {
            margin: 0 0 24px;
            font-size: 1.6rem;
            color: #1a1a2e;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        h2::before {
            content: '🏆';
            font-size: 1.4rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead tr {
            background: #4f46e5;
            color: #fff;
        }

        thead th {
            padding: 14px 18px;
            text-align: left;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        tbody tr {
            border-bottom: 1px solid #e5e7eb;
            transition: background 0.2s;
        }

        tbody tr:last-child {
            border-bottom: none;
        }

        tbody tr:hover {
            background: #f5f3ff;
        }

        tbody td {
            padding: 14px 18px;
            color: #374151;
            font-size: 0.95rem;
        }

        .rank {
            font-weight: 700;
            color: #4f46e5;
        }

        .total {
            font-weight: 600;
            color: #059669;
        }

        .no-data {
            text-align: center;
            padding: 24px;
            color: #9ca3af;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Top 3 Customers</h2>

        <!-- HTML Table Structure -->
        <table border="1">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Total Spent</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($topCustomers)): ?>
                    <?php foreach ($topCustomers as $index => $customer): ?>
                        <tr>
                            <td class="rank"><?= $index + 1 ?></td>
                            <td><?= htmlspecialchars($customer['name']) ?></td>
                            <td><?= htmlspecialchars($customer['email']) ?></td>
                            <td class="total">$<?= number_format($customer['total_spent'], 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" class="no-data">No customer data found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>