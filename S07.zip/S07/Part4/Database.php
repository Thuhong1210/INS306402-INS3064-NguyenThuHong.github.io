<?php
/**
 * Database.php
 * Implements the Singleton design pattern to ensure only ONE PDO connection
 * is created and reused throughout the entire application lifecycle.
 */
class Database {
    // Holds the single instance of this class
    private static $instance = null;

    // Holds the PDO connection object
    private $connection;

    /**
     * Private constructor — prevents direct instantiation with `new Database()`.
     * Creates the PDO connection with secure options.
     */
    private function __construct() {
        $dsn = "mysql:host=localhost;dbname=ecommerce_db;charset=utf8mb4";
        $options = [
            // Throw exceptions on DB errors instead of silently failing
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            // Return rows as associative arrays by default
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            // Use real prepared statements (more secure, not emulated)
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            $this->connection = new PDO($dsn, 'root', '', $options);
        } catch (PDOException $e) {
            // Re-throw with the original message to surface the real error
            throw new PDOException($e->getMessage(), (int)$e->getCode());
        }
    }

    /**
     * getInstance() — Returns the single shared instance of Database.
     * Creates it on first call; returns the cached one on all subsequent calls.
     */
    public static function getInstance(): self {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    /**
     * getConnection() — Returns the raw PDO connection for running queries.
     */
    public function getConnection(): PDO {
        return $this->connection;
    }
}
?>
