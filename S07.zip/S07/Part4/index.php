<?php
/**
 * index.php — Product Admin Dashboard
 *
 * Features:
 *  - Lists all products with Category Name via JOIN
 *  - Dynamic name search using LIKE with a prepared statement placeholder
 *  - Category filter using a <select> populated from the DB
 *  - Visual red highlight for stock < 10
 *  - Zero raw user input concatenated into SQL (PDO placeholders only)
 */
require_once 'Database.php';

// Get the single PDO connection via Singleton
$pdo = Database::getInstance()->getConnection();

// ─────────────────────────────────────────────
// 1. Populate the Category <select> dropdown
//    Simple SELECT — no user input involved, no placeholders needed.
// ─────────────────────────────────────────────
$catStmt = $pdo->query("SELECT id, category_name FROM categories ORDER BY category_name");
$categories = $catStmt->fetchAll();

// ─────────────────────────────────────────────
// 2. Read & sanitize filter values from GET
//    We do NOT use these directly in SQL strings.
//    They are bound via PDO placeholders below.
// ─────────────────────────────────────────────
$searchName    = isset($_GET['search'])   ? trim($_GET['search'])      : '';
$filterCatId   = isset($_GET['category']) ? (int)$_GET['category']     : 0;

// ─────────────────────────────────────────────
// 3. Build the SQL query dynamically but safely
//
//    JOIN explanation:
//      products LEFT JOIN categories
//        → products.category_id = categories.id
//      We use LEFT JOIN so products with no category (NULL) still appear.
//
//    Prepared Statement explanation:
//      Instead of writing ... WHERE p.name LIKE '%$searchName%'  (UNSAFE),
//      we write ... WHERE p.name LIKE :name and bind the value separately.
//      PDO escapes it automatically, preventing SQL injection.
// ─────────────────────────────────────────────
$sql = "
    SELECT
        p.id,
        p.name,
        p.price,
        c.category_name,   -- from the JOIN below
        p.stock
    FROM products p
    -- LEFT JOIN: keeps products even if category_id is NULL
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE 1=1
";

// Array to hold bound values — avoids concatenating user input into SQL
$params = [];

// Append name filter only if user typed something
if ($searchName !== '') {
    // LIKE placeholder: the % wildcards are added to the VALUE, not the SQL string
    $sql .= " AND p.name LIKE :name";
    $params[':name'] = '%' . $searchName . '%';
}

// Append category filter only if a category was selected (0 = "All")
if ($filterCatId > 0) {
    $sql .= " AND p.category_id = :cat_id";
    $params[':cat_id'] = $filterCatId;
}

$sql .= " ORDER BY p.id ASC";

// Prepare → Bind params → Execute (the safe PDO flow)
$stmt = $pdo->prepare($sql);
$stmt->execute($params);   // PDO binds all values securely
$products = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Admin Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', sans-serif;
            background: #0f172a;
            color: #e2e8f0;
            min-height: 100vh;
        }

        /* ── Top Bar ── */
        header {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            border-bottom: 1px solid #1e3a5f;
            padding: 20px 36px;
            display: flex;
            align-items: center;
            gap: 14px;
        }
        header .logo {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.2rem;
        }
        header h1 { font-size: 1.3rem; font-weight: 700; color: #f1f5f9; }
        header span { font-size: 0.8rem; color: #64748b; margin-left: 4px; }

        /* ── Main Layout ── */
        main { max-width: 1200px; margin: 0 auto; padding: 32px 24px; }

        /* ── Filter Card ── */
        .filter-card {
            background: #1e293b;
            border: 1px solid #2d3f55;
            border-radius: 16px;
            padding: 24px 28px;
            margin-bottom: 28px;
            display: flex;
            gap: 16px;
            align-items: flex-end;
            flex-wrap: wrap;
        }
        .filter-group { display: flex; flex-direction: column; gap: 6px; flex: 1; min-width: 180px; }
        .filter-group label { font-size: 0.75rem; font-weight: 600; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.05em; }
        .filter-group input,
        .filter-group select {
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 8px;
            color: #e2e8f0;
            padding: 10px 14px;
            font-size: 0.9rem;
            font-family: inherit;
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
            width: 100%;
        }
        .filter-group input:focus,
        .filter-group select:focus {
            border-color: #6366f1;
            box-shadow: 0 0 0 3px rgba(99,102,241,0.2);
        }
        .filter-group select option { background: #1e293b; }

        .btn {
            padding: 10px 24px;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            border: none;
            transition: all 0.2s;
            font-family: inherit;
            white-space: nowrap;
        }
        .btn-primary {
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: #fff;
        }
        .btn-primary:hover { opacity: 0.88; transform: translateY(-1px); }
        .btn-reset {
            background: #1e293b;
            color: #94a3b8;
            border: 1px solid #334155;
        }
        .btn-reset:hover { border-color: #6366f1; color: #e2e8f0; }

        /* ── Stats Strip ── */
        .stats { display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; }
        .stat-pill {
            background: #1e293b;
            border: 1px solid #2d3f55;
            border-radius: 999px;
            padding: 6px 16px;
            font-size: 0.8rem;
            color: #94a3b8;
        }
        .stat-pill strong { color: #e2e8f0; }
        .stat-pill.danger { border-color: #7f1d1d; color: #fca5a5; }
        .stat-pill.danger strong { color: #ef4444; }

        /* ── Table ── */
        .table-wrap {
            background: #1e293b;
            border: 1px solid #2d3f55;
            border-radius: 16px;
            overflow: hidden;
        }
        table { width: 100%; border-collapse: collapse; }
        thead tr {
            background: linear-gradient(90deg, #1a2744 0%, #1e293b 100%);
            border-bottom: 2px solid #2d3f55;
        }
        thead th {
            padding: 14px 18px;
            text-align: left;
            font-size: 0.72rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #64748b;
        }
        tbody tr {
            border-bottom: 1px solid #1e3a5f;
            transition: background 0.15s;
        }
        tbody tr:last-child { border-bottom: none; }
        tbody tr:hover { background: rgba(99,102,241,0.06); }
        tbody td {
            padding: 14px 18px;
            font-size: 0.9rem;
            color: #cbd5e1;
        }

        /* ── ID badge ── */
        .id-badge {
            display: inline-block;
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 6px;
            padding: 2px 8px;
            font-size: 0.78rem;
            font-weight: 600;
            color: #6366f1;
            font-family: monospace;
        }

        /* ── Category chip ── */
        .cat-chip {
            display: inline-block;
            background: rgba(99,102,241,0.12);
            color: #a5b4fc;
            border-radius: 999px;
            padding: 3px 10px;
            font-size: 0.78rem;
            font-weight: 500;
        }

        /* ── Price ── */
        .price { font-weight: 600; color: #34d399; }

        /* ── Stock: normal ── */
        .stock-ok {
            font-weight: 600;
            color: #60a5fa;
        }

        /* ── STOCK LOW: visual alert for stock < 10 ── */
        tr.low-stock { background: rgba(127, 29, 29, 0.25) !important; }
        tr.low-stock:hover { background: rgba(127, 29, 29, 0.38) !important; }
        .stock-low {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            font-weight: 700;
            color: #ef4444;
        }
        .stock-low::before {
            content: '⚠';
            font-size: 0.85rem;
        }

        /* ── Empty state ── */
        .empty {
            text-align: center;
            padding: 60px 20px;
            color: #475569;
        }
        .empty .icon { font-size: 3rem; margin-bottom: 12px; }
        .empty p { font-size: 1rem; }

        /* ── Responsive ── */
        @media (max-width: 640px) {
            .filter-card { flex-direction: column; }
            thead th:nth-child(1),
            tbody td:nth-child(1) { display: none; }
        }
    </style>
</head>
<body>

<header>
    <div class="logo">📦</div>
    <div>
        <h1>Product Admin <span>/ Dashboard</span></h1>
    </div>
</header>

<main>

    <!-- ── Filter Form ── -->
    <!--
        All filter values are submitted via GET so the URL stays shareable/bookmarkable.
        User input is NEVER concatenated into SQL — it is bound via PDO placeholders.
    -->
    <form method="GET" action="index.php" class="filter-card">

        <!-- Search by name → binds to :name LIKE placeholder in SQL -->
        <div class="filter-group">
            <label for="search">🔍 Search by Name</label>
            <input
                type="text"
                id="search"
                name="search"
                placeholder="e.g. iPhone…"
                value="<?= htmlspecialchars($searchName) ?>"
                autocomplete="off"
            >
        </div>

        <!-- Category dropdown → populated from DB, value binds to :cat_id in SQL -->
        <div class="filter-group">
            <label for="category">🏷️ Filter by Category</label>
            <select id="category" name="category">
                <option value="0">— All Categories —</option>
                <?php foreach ($categories as $cat): ?>
                    <option
                        value="<?= (int)$cat['id'] ?>"
                        <?= ($filterCatId === (int)$cat['id']) ? 'selected' : '' ?>
                    >
                        <?= htmlspecialchars($cat['category_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Apply Filters</button>
        <a href="index.php" class="btn btn-reset">Reset</a>
    </form>

    <!-- ── Stats Strip ── -->
    <?php
        $lowStockCount = array_reduce($products, fn($c, $p) => $c + ($p['stock'] < 10 ? 1 : 0), 0);
    ?>
    <div class="stats">
        <div class="stat-pill">Showing <strong><?= count($products) ?></strong> product(s)</div>
        <?php if ($searchName): ?>
            <div class="stat-pill">Search: <strong>"<?= htmlspecialchars($searchName) ?>"</strong></div>
        <?php endif; ?>
        <?php if ($filterCatId > 0): ?>
            <?php $catName = array_column($categories, 'category_name', 'id')[$filterCatId] ?? ''; ?>
            <div class="stat-pill">Category: <strong><?= htmlspecialchars($catName) ?></strong></div>
        <?php endif; ?>
        <?php if ($lowStockCount > 0): ?>
            <div class="stat-pill danger">⚠ <strong><?= $lowStockCount ?></strong> low-stock item(s)</div>
        <?php endif; ?>
    </div>

    <!-- ── Product Table ── -->
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Product Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Stock</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($products)): ?>
                    <tr>
                        <td colspan="5">
                            <div class="empty">
                                <div class="icon">🔎</div>
                                <p>No products match your filters.</p>
                            </div>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($products as $product): ?>
                        <!--
                            Visual Alert: if stock < 10 → add .low-stock class to the <tr>
                            This highlights the entire row in red per the requirement.
                        -->
                        <tr class="<?= ($product['stock'] < 10) ? 'low-stock' : '' ?>">
                            <td><span class="id-badge">#<?= (int)$product['id'] ?></span></td>
                            <td><?= htmlspecialchars($product['name']) ?></td>
                            <td>
                                <?php if ($product['category_name']): ?>
                                    <span class="cat-chip"><?= htmlspecialchars($product['category_name']) ?></span>
                                <?php else: ?>
                                    <span style="color:#475569;font-size:0.82rem;">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="price"><?= number_format((float)$product['price'], 0, '.', ',') ?> ₫</td>
                            <td>
                                <?php if ($product['stock'] < 10): ?>
                                    <!-- Stock is critically low → red alert badge -->
                                    <span class="stock-low"><?= (int)$product['stock'] ?> units</span>
                                <?php else: ?>
                                    <span class="stock-ok"><?= (int)$product['stock'] ?> units</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</main>

</body>
</html>
